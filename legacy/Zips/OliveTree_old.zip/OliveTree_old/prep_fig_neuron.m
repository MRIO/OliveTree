% prep_fig_neuron.m
function prep_fig_neuron(fig, ncols)


whratio = .8;
switch ncols
case 1
	w = 85;
	h = 85*whratio;
case 1.5
	w = 114;
	h = 114*whratio;
case 2
	w = 174;
	h = 174*whratio;
end


set(fig,'paperunits','centimeters')
set(fig,'paperposition',[0.6350 6.3500 0.6350+w 6.3500+h])

print(fig, '-dpng', '-r300', 'bla')




% 1colu , 85 mm; 1.5 column, 114 mm; and 2 column, 174 


% Figures

% Each figure should be able to fit on a single 8.5 x 11 inch page. Please do not send figure panels as individual files. We use three standard widths for figures: 1 column, 85 mm; 1.5 column, 114 mm; and 2 column, 174 mm (the full width of the page). Although your figure size may be reduced in the print journal, please keep these widths in mind. For Previews and other three-column formats, these widths are also applicable, though the width of a single column will be 55 mm.

% Different panels should be labeled with capital letters, and Helvetica or Arial font should be used for any text. Line or stroke width should not be narrower than half a point, and gray fills should be kept at least 20% different from other fills and no lighter than 10% or darker than 80%. Files should be provided in accordance with the following:

% Figures should be submitted as separate files.
% For initial submission, we prefer TIFF or PDF figure formats. We will also accept JPEG or EPS files. PDF file size should be less than 3 MB.
% For final production, we prefer high-resolution TIFF or PDF files.* Each figure file should be no more than 20 MB.
% For color figures, the resolution should be 300 dpi at the desired print size.
% For black and white figures, the resolution should be 500 dpi at the desired print size.
% For line-art figures, the resolution should be 1,000 dpi at the desired print size.
% Make sure that any raster artwork within the source document is at the appropriate minimum resolution.
% When color is involved, it should be encoded as RGB.
% Always include/embed fonts and only use Helvetica or Arial fonts.
% Limit vertical space between parts of an illustration to only what is necessary for visual clarity.
% Line weights should range from 0.35 to 1.5 pt.
% When using layers, reduce to one layer before saving your image (Flatten Artwork).
% A scale bar, rather than magnification, must be provided for any micrographs.

% *NOTE: The journal Cell will also accept the AI file type for Leading Edge figures.

% *NOTE: Please review the Data Processing Policy at the bottom of this page and confirm that your figures and manuscript adhere to this policy.

% File Types

% TIFF

% TIFF (Tagged Image File Format) and PDF are the preferred file types for final production files. Virtually all common artwork-creation software is capable of saving files in TIFF format. TIFF is the recommended file format for bitmap, grayscale, and color images. TIFF supports several good compression schemes, ensuring that file sizes are kept to a minimum to aid easy file transfer. The LZW compression option should always be used. 

% PDF

% PDF and TIFF are the preferred file types for final production files.