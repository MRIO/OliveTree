% generate_PRC.m

% 0. generate steady_state
% 1.   Generate unperturbed network
% 1.2. Measure phase
% 1.3. Partition one phase in 9 intervals from 0 to 1

% 1.4. Stimulate network 9 times
% 1.5. Measure phases of stimulated population
% 1.6. For every stimulated phase, find next peak


% assumptions:    
% 
% 	1. Cells have slightly different oscillatory properties as a
% 		function of their randomized calcium distribution 
%   2. Cells have slightly different after depolarization properties owing to varying I_h and I_int
% 
%   3. 100 cells in a deformed 2d mesh, connected with a 2 cell radius (#decisionpoint)
% 
%   4. add some additive noise, uncorrelated between cells
% 
% 
% initial conditions:
% 		All simulations have the same initial state:
%		   Syncrhonized transients in the absence of noise due to 1 and 2 and no gap junctions.
% 
% manipulation:
% 
% 		Ampa or GABA pulse to subpopulation at increasing phases 
% 
% experimental conditions:
% 
%	1. With gaps and without gaps
%	2. With input and without input
% 
% measurements:
%   1. Phase difference with respect to non-stimulated network
% 	2. Time to for whole network to resync
% 


prep_conditions    = 1;
compute_transients = 1; transienttime = 2000;
stimulate    = 1;
volumetric_activity = 0; % slow

savemovies = 0;
snapshot = 1;
gpu = 1;

% rseed = 5; % this seed leads to wave propagations and solitons
rseed = 1;
rng(rseed, 'twister')
to_report = {'V_soma'};

% global 
	dt =0.025;
	fs = 1/dt;
	simtime  = 550;

% network parameters
	depth = 3; breadth = 5; height = 5;
	netsize = [depth breadth height];
	noneurons = prod(netsize);
	
	% inputmasktype = 'mid_layer';
	inputmasktype = 'random_all';
	inputmask = ones(noneurons,1);
	inputmask = create_input_mask(netsize,inputmasktype);
	
	gap = 0.01; % mS/cm^2
	
	def_neurons = createDefaultNeurons(noneurons);
		alp = 7;
		bet = 2;
		sup = [0.5 1.1];
		GCAL = BetaDistributions('alpha', alp, 'beta', bet, 'no_draws', ...
		   noneurons, 'support', sup,'plot_distributions',0); 
		g_CaL = GCAL.sampleDraws{1}';				
		def_neurons.g_CaL = g_CaL;
		def_neurons.g_int = .13 + rand(noneurons,1)*.03;

	W_3d = createW('3d_euclidean_rndwalk', netsize,2.5,gap, 1, 1,3);
	% W_3d = createW('3d', netsize,2.5,gap, 1, 1,3);

	noise_parameters = [0 0 0 rseed]; % pA/ms per cell - 3.5 3 1

% perturbation
	pert.mask  	  {1} = inputmask;
	pert.amplitude{1} = 1;
	pert.duration {1} = 5;
	pert.type	  {1} = 'gaba_soma';

	pert.mask  	  {2} = inputmask;
	pert.amplitude{2} = 1;
	pert.duration {2} = 5;
	pert.type	  {2} = 'gaba_dend';

% noise
	sametoall = 0.1;

% calc steady state
if ~exist('steady_state')
	[steady_state] = IOnet_new( 'networksize', netsize ,'time',transienttime,'delta',dt,'cell_parameters', def_neurons ,'W',W_3d.W,'ou_noise', noise_parameters, 'sametoall',sametoall);
end

[unperturbed_state] = IOnet_new( 'networksize', netsize ,'time',simtime, ...
								'delta',dt,'cell_parameters', def_neurons ,'W',W_3d.W,'ou_noise', noise_parameters, ...
								'sametoall',sametoall, 'tempState', steady_state.lastState);

% measure unperturbed phases
phaseResults = measureGlobalSync(unperturbed_state, [1:simtime],1);
phases = phaseResults.hilbert.hilbert;

% find original peaks
[PKS LOCS] = findpeaks(mean(phases), 'minpeakdistance',50);
meanT = mean(diff(LOCS));

pertphases = round(linspace(LOCS(1),LOCS(2),10));
meanT = mean(diff(pertphases));


% add perturbation at different phases
k = 0;
for pertphase = pertphases
	k = k+1;

	pert.triggers {1} = pertphase;
	pert.triggers {2} = pertphase;

	simPert{k} = IOnet_new( 'networksize', netsize , 'time',simtime,'delta',dt, ...
		'cell_parameters', def_neurons ,'W',W_3d.W,'ou_noise', noise_parameters,...
		'sametoall',sametoall, 'perturbation', pert, 'tempState', steady_state.lastState);

	replayResults(simPert{k}, [1:2],0)
	
	close all

	simPert{k}.condition.perturbation_mask = pert.mask{1};
	simPert{k}.condition.perturbation_onsets = pert.triggers{1};

end

k = 0; t = [LOCS(2)-100:LOCS(2)+100];
for pertphase = pertphases
	k = k+1;

	perturberdPhaseResults = measureGlobalSync(simPert{k}, [1:simtime],0);
		perturbedPhases 	   = perturberdPhaseResults.hilbert.hilbert;

		averagephases(k,:) = mean(perturbedPhases(find(pert.mask{1}),:));
		averageVm(k,:)     = mean(simPert{k}.networkHistory.V_soma(find(pert.mask{1}),:));

	% find new peaks
	[newPKS newLOCS{k}] = findpeaks(mean(perturbedPhases(find(pert.mask{1}),t)), 'minpeakdistance',100);

	peakDelta(k) = LOCS(2) - (t(1) + newLOCS{k}(1));


end


PRC = (peakDelta/meanT)*2*pi;



% k = 0; t = [LOCS(2)-100:LOCS(2)+100];
% for pertphase = pertphases
% 	k = k+1;

% 	perturberdPhaseResults = measureGlobalSync(simPert{k}, [1:simtime],1);
% 		perturbedPhases{k} 	   = perturberdPhaseResults.hilbert.hilbert;
% 		sync_stim(k) = perturberdPhaseResults.stats.firstordersync(1);
% 		sync_all(k) = perturberdPhaseResults.stats.overallsync(1);



% end


