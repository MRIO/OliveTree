% pspace tests

% from Schweighofer 1998:
% Using the following parameter values (conductances in mS/
% cm2), soma: g 􏰅 70, g 􏰅 18, g 􏰅 1.0, and g 􏰅 1.5; Na K_dr CA_l h
% dendrite: gCa_h 􏰅 4.0 and gK_Ca 􏰅 35; leak: gls 􏰅 gld 􏰅 0.015 and vl 􏰅 􏰄10 mV; cell morphology:
% gint 􏰅 0.13 and p 􏰅 0.20, data from our standard cell model were consistent with many reported experimental findings from actual IO neurons.
% STEADY-STATE PROPERTIES. The membrane potential with no
% input current (I 􏰅 0 􏰈A/cm2) was 􏰄57 mV, whereas the app
% input resistance derived from the voltage-current curve was 36
% M􏰐. When I 􏰅= -􏰄5 􏰈A/cm2, the potential was 􏰄80.3 mV app
% and the input resistance was 14 M􏰐, reflecting the effect of the h current.
% When Iapp 􏰅 􏰃5 􏰈A/cm2, the membrane potential was 􏰄46 mV and the input resistance was only 10 M􏰐 because of the effect of the delayed rectifier current.
% These steady-state values are in agreement with published experimental data (see for instance Table 1 in Llina ́s and Yarom 1981a;
% Fig. 1A in Yarom and Llina ́s 1987; Manor 1995). Note that 1 􏰈A/cm2 corresponds to 0.1 nA for a total cell surface of 10,000 u􏰈m2.


% clear

% [================================================]
% 		 global parameters
% [================================================]
gpu = 0;


% [================================================]
% 		 simulation parameters
% [================================================]
ststtime = 3;
simtime  = 10; W = zeros(noneurons);


% possible state variables to_report
activations =  {'V_soma','V_dend','V_axon','Calcium_l', 'Calcium_r', 'Ca2Plus', 'Potassium_s', 'Hcurrent_q','Sodium_m_a', 'Sodium_h_a','Potassium_x_a'};
currents = {'V_soma','V_dend','V_axon', 'I_CaL', 'I_ds', 'I_as', 'I_Na_s', 'I_ls', 'I_Kdr_s', 'I_K_s', 'I_CaH', 'I_sd', 'I_ld', 'I_K_Ca', 'I_cx36', 'I_h', 'I_K_a', 'I_sa', 'I_la', 'I_Na_a'};
vsoma  = {'V_soma'};

to_report = vsoma;
cell_function = 'vanilla';
delta = .025;
currentstep1 = 20; %uA/cm^2 -> .1 nA for a cell with 10000um^2
currentstep2 = -10; %uA/cm^2 -> .1 nA for a cell with 10000um^2

% [================================================]
% 		 cell parameters
% [================================================]

% parameter ranges
p1 = [.6:.2:1]; 		% CalciumL - conductance range
p2 = [45 65];      		% g_Ca_K
p3 = [.1 .13 .15]; 	% g_int
p4 = [.12 .48];       		% g_h
p5 = [.15 .2];       		% V_h
[p{1} p{2} p{3} p{4} p{5}] = ndgrid(p1,p2,p3,p4,p5);

Plist = [p{1}(:) p{2}(:) p{3}(:) p{4}(:) p{5}(:)];

noneurons = length(p{1}(:));
netsize = [1 noneurons 1];noneurons = prod(netsize);


def_neurons = createDefaultNeurons(noneurons);
def_neurons.g_CaL    = p{1}(:);
def_neurons.g_K_Ca   = p{2}(:);
def_neurons.g_int 	 = p{3}(:);
def_neurons.g_h 	 = p{4}(:);
def_neurons.p2 	 = p{5}(:);
% def_neurons.C_m  = 



% [================================================]
% 		 perturbation
% [================================================]

gnoise = [2 5 0 0];
gnoise = [0 0 0 0];

% perturbation_onsets{2} = 100;
% perturbation_mask{2} 	= glu_mask; % selection of stimulated neurons
% perturbation_type{2} = 'ampa';
% perturbation_pulse_duration{2} = exc_pulse_dur;

% perturbation_onsets{3} = gaba_onsets_dend;
% perturbation_mask{3} 	= gaba_mask_dend; % selection of stimulated neurons
% perturbation_type{3} = 'gaba_dend';
% perturbation_pulse_duration{3} =  gaba_pulse_dur;

% perturbation_onsets{4} = gaba_onsets_soma;
% perturbation_mask{4} 	= gaba_mask_soma; % selection of stimulated neurons
% perturbation_type{4} = 'gaba_soma';
% perturbation_pulse_duration{4} =  gaba_pulse_dur;					

% pert.triggers{1} = .001; % proportion of neurons receiveing ampa per bin
% pert.mask{1} 	= create_input_mask(netsize,'all'); % selection of stimulated neurons
% pert.type{1} = 'ampa_noise';
% pert.duration{1} =  1;					


pert = [];


% [================================================]
% 		 'steady' state
% [================================================]


if ~exist('st_st','var')
	% calc steady state
	
	st_st = IOnet_new('cell_function', cell_function ,'networksize', netsize, 'cell_parameters', def_neurons, 'time', ststtime ,'gpu', gpu,'to_report', to_report ,'delta',delta );
end

simcount= 0;

simcount = simcount+1;
	
I_app = zeros(noneurons, simtime*(1/delta));
I_app(:,(200:210)*(1/delta)) = currentstep1/(1/delta); % nAmpere 20/dt [nA/s.cm^2] 
I_app(:,(500:600)*(1/delta)) = currentstep2/(1/delta);
I_app = [];

% [===========================================================================================================]
   [transients] = IOnet_new('tempState', st_st.lastState ,'cell_parameters', def_neurons, ...
   	'networksize', netsize,'appCurrent',I_app,'time',simtime ,'W', W ,'ou_noise', gnoise , ...
   	'gpu', gpu ,'to_report',currents, 'cell_function', cell_function ,'delta',delta, ...
   	'perturbation', pert);

   transients.Plist = Plist;
% [===========================================================================================================]

spks = spikedetect(transients, 0,0);


figure
imagesc(st_st.networkHistory.V_soma,[-150 20]), colorbar
set(gca,'ytick', [1:noneurons],'yticklabel', num2str(Plist),'fontsize',8)
legend(num2str(Plist))


figure
ca = axis;
set(0,'defaultaxescolororder', linspecer(length(Plist)))
pl1 = plot([1:1000],   st_st.networkHistory.V_soma');
legend(num2str(Plist))


figure
imagesc(transients.networkHistory.V_soma,[-150 20]), colorbar
set(gca,'ytick', [1:noneurons],'yticklabel', num2str(Plist),'fontsize',8)
title([num2str(spks.popfrequency) ' Hz'])

figure
ca = axis;
set(0,'defaultaxescolororder', linspecer(length(Plist)));
pl2 = plot([1:simtime],   transients.networkHistory.V_soma');
legend(num2str(Plist))

