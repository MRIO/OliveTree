% createDefaultNeurons.m
function cell_parameters = createDefaultNeurons(varargin)
% createDefaultNeurons(noneurons, celltypes, gapcompensation)

	ip = inputParser;
	ip.addOptional('noneurons',0)
	
	ip.addParamValue('celltypes', 'none') 
	ip.addParamValue('gapcompensation', 0) 
	ip.addParamValue('nogapcompensation', 0);
	ip.addParamValue('shuffle', 0) 
	ip.addParamValue('rng', rng(0))
	
	ip.parse(varargin{:});

	noneurons = ip.Results.noneurons;
	celltypes = ip.Results.celltypes;
	gapcompensation = ip.Results.gapcompensation;
	shuffle = ip.Results.shuffle;
	nogapcompensation = ip.Results.nogapcompensation;
	rng(ip.Results.rng)
	
cell_parameters = defneurons(noneurons);


switch celltypes

	case 'param_sweep'

		p1 = [.5:.1:1.1]; 		% CalciumL - conductance range
		p2 = [.0];      	    % g_h_s
		p3 = [.11 .13]; 		% g_int
		p4 = [.12:.12:.48];      	% g_h
		p5 = [-38];       	% V_h
		p6 = [45 55];		% Ca act Potassium: not voltage dependent 
		p7 = [4.5];
		p8 = [.013];    % leak
		[p{1} p{2} p{3} p{4} p{5} p{6} p{7} p{8}] = ndgrid(p1,p2,p3,p4,p5,p6,p7,p8);

		Plist = [p{1}(:) p{2}(:) p{3}(:) p{4}(:) p{5}(:) p{6}(:) p{7}(:) p{8}(:)]; 

		psweepnoneurons = length(p{1}(:));

		cell_parameters = defneurons(psweepnoneurons);
		
		cell_parameters.g_CaL    = p{1}(:);
		cell_parameters.g_h_s    = p{2}(:);
		cell_parameters.g_int 	 = p{3}(:);
		cell_parameters.g_h 	 = p{4}(:);
		cell_parameters.V_h 	 = p{5}(:);
		cell_parameters.g_K_Ca   = p{6}(:);       
		cell_parameters.g_CaH    = p{7}(:);     % High-threshold calcium
		cell_parameters.g_ld     = p{8}(:);
		
		cell_parameters.Plist = Plist;

	case 'randomized'

		cell_parameters = defneurons(noneurons);
		
		cell_parameters.g_CaL    = cell_parameters.g_CaL   +  rand(noneurons,1)*(-.6);
		cell_parameters.g_int 	 = cell_parameters.g_int   +  rand(noneurons,1)*(-.02);
		cell_parameters.g_h 	 = cell_parameters.g_h 	   +  rand(noneurons,1)*(4);
		cell_parameters.g_K_Ca   = cell_parameters.g_K_Ca  +  rand(noneurons,1)*10;       
		cell_parameters.g_ld     = cell_parameters.g_ld    +  rand(noneurons,1)*(-0.003);
		cell_parameters.g_la     = cell_parameters.g_la    +  rand(noneurons,1)*(-0.003);
		cell_parameters.g_ls     = cell_parameters.g_ls    +  rand(noneurons,1)*(-0.003);
		cell_parameters.gbar_ampa_soma     = .1   +  rand(noneurons,1)*(.15);

		cell_parameters.Plist = [cell_parameters.g_CaL(:) cell_parameters.g_int(:) cell_parameters.g_h(:) cell_parameters.g_K_Ca(:) cell_parameters.g_ld(:)];
		

	case 'permuted'

		p1 = [.5:.1:1.1]; 		% CalciumL - conductance range
		p2 = [.0];      	    % g_h_s
		p3 = [.11 .13]; 		% g_int
		p4 = [.12:.12:.48];      	% g_h
		p5 = [-38];       	% V_h
		p6 = [45 55];		% Ca act Potassium: not voltage dependent 
		p7 = [4.5];
		p8 = [.013];    % leak
		[p{1} p{2} p{3} p{4} p{5} p{6} p{7} p{8}] = ndgrid(p1,p2,p3,p4,p5,p6,p7,p8);

		Plist = [p{1}(:) p{2}(:) p{3}(:) p{4}(:) p{5}(:) p{6}(:) p{7}(:) p{8}(:)]; 

		psweepnoneurons = length(p{1}(:));

		cell_parameters = defneurons(psweepnoneurons);
		
		cell_parameters.g_CaL    = p{1}(randi(noneurons,noneurons,1));
		cell_parameters.g_h_s    = p{2}(randi(noneurons,noneurons,1));
		cell_parameters.g_int 	 = p{3}(randi(noneurons,noneurons,1));
		cell_parameters.g_h 	 = p{4}(randi(noneurons,noneurons,1));
		cell_parameters.V_h 	 = p{5}(randi(noneurons,noneurons,1));
		cell_parameters.g_K_Ca   = p{6}(randi(noneurons,noneurons,1));       
		cell_parameters.g_CaH    = p{7}(randi(noneurons,noneurons,1));     % High-threshold calcium
		cell_parameters.g_ld     = p{8}(randi(noneurons,noneurons,1));
		

		cell_parameters.Plist = [cell_parameters.g_CaL(:) cell_parameters.g_int(:) cell_parameters.g_h(:) cell_parameters.g_K_Ca(:) cell_parameters.g_ld(:)];;




	otherwise


end


if gapcompensation
		% compensation for gap junctions
		
		cell_parameters.g_CaL = cell_parameters.g_CaL + .1*gapcompensation;

		cell_parameters.g_ld  = cell_parameters.g_ld  - 0.003*gapcompensation;
		cell_parameters.g_la  = cell_parameters.g_la  - 0.003*gapcompensation;
		cell_parameters.g_ls  = cell_parameters.g_ls  - 0.003*gapcompensation;
end

if nogapcompensation
		cell_parameters.g_CaL = cell_parameters.g_CaL - .1;
		% cell_parameters.g_int = cell_parameters.g_int + 0.03;
		cell_parameters.g_ld  = cell_parameters.g_ld  + 0.003;
		% cell_parameters.g_K_Ca= cell_parameters.g_K_Ca - 10;
end




% [=================================================================]
%  create default neurons
% [=================================================================]

function cell_parameters = defneurons(noneurons)

O = ones(noneurons,1);

%% Cell properties

% Capacitance
cell_parameters.C_m    =   1 .* O; % mF/cm^2 
 

% [================================================]
% 		 conductances
% [================================================]
% Defaults

% Somatic conductances (mS/cm2)
cell_parameters.g_CaL    =  1.1   .*O; 
cell_parameters.g_Na_s   =  150   .*O;      % Sodium
cell_parameters.g_Kdr_s  =  9.0   .*O;      % Potassium
cell_parameters.g_K_s    =  5     .*O;      % Potassium
cell_parameters.g_ls     =  0.016 .*O;      % Leaks
    
% Dendritic conductances (mS/cm2)
cell_parameters.g_K_Ca   =  35      .*O;       % Potassium: not voltage dependent -- now a parameter
cell_parameters.g_CaH    =  4.5     .*O;     % High-threshold calcium
cell_parameters.g_ld     =  0.016  .*O;   % Leak
cell_parameters.g_h      =  .12    .*O;    % H current .12
cell_parameters.g_h_s    =  .12    .*O;    % H current, somatic


% Axon hillock conductances (mS/cm2)
cell_parameters.g_Na_a   =  240		.*O;      % Sodium
cell_parameters.g_K_a    =  240		.*O;      % Potassium
cell_parameters.g_la     =  0.016	.*O;      % Leak
    
% Cell morphology
cell_parameters.p1     = 0.25		.*O;        % Cell surface ratio soma/dendrite
cell_parameters.p2     = 0.15 		.*O;        % Cell surface ratio axon(hillock)/soma

cell_parameters.g_int  = 0.13		.*O;        % Cell internal conductance  -- now a parameter


% synaptic conductances

cell_parameters.gbar_gaba_dend  			     = O*.25;
cell_parameters.gbar_gaba_soma  			 	 = O*.5;
cell_parameters.gbar_ampa_soma 					 = O*.1;


%% Reversal potentials
cell_parameters.V_Na =  55 .* O;       % Sodium
cell_parameters.V_K  = -75 .* O;       % Potassium
cell_parameters.V_Ca = 120 .* O;       % Calcium
cell_parameters.V_h  = -43 .* O;       % H current
cell_parameters.V_l  =  10 .* O;       % Leak

cell_parameters.V_gaba_dend = -70 .*O; % from Devor and Yarom, 2002
cell_parameters.V_gaba_soma = -63 .*O; % from Devor and Yarom, 2002
cell_parameters.V_ampa_soma = 0 	  .*O; % from Cian McDonnel et al 2012


cell_parameters.arbitrary = 1 .* O;


