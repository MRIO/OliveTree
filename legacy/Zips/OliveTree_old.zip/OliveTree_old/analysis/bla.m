% bla.m


load /Users/M/Projects/Experiments/Olive/Experiments/CS_and_stim_times_140107_Ch22.mat


% Rec_data_140107_Ch22

% Rec_data_140107_Ch22 =

%     CS_times: [2844x1 double]
%     AP_times: [1189x1 double]

triggers = Rec_data_140107_Ch22.AP_times;
spikes = Rec_data_140107_Ch22.CS_times;

sometrigs = triggers(1:100);


trigrast = ETR(sometrigs*1e3, spikes*1e3 ,'bin', 10, 'span', 2000);