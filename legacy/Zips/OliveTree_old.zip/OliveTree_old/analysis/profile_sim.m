function R = profile_sim(sim)
% plot partial correlations between cell parameters and cell behavior


   	T = sim;
   	tslice = [1:min(1000,sim.duration)];
	V = T.networkHistory.V_soma(:,tslice);
	CAL = T.cellParameters.g_CaL;
	IH  = T.cellParameters.g_h;
	g_int= T.cellParameters.g_int;
	g_l  = T.cellParameters.g_ls;

	plotme = 1;

	K = measureGlobalSync(sim,'plotme', 0,'duration',tslice); %, 'duration', tslice
	
	spikes  = spikedetect(sim);

	freq_each = mean(K.instantaneousFrequency)';

	freq = median(freq_each);
	ampl = max(V, [], 2) - min(V, [], 2);
	meanVm = mean(V, 2);
	spks = spikes.spikespercell'/length(tslice)*1e3;

	R.allneurons = table(CAL, IH, g_int, g_l, freq_each, ampl, meanVm, spks);

	[rho pval] = partialcorr(table2array(R.allneurons));

	R.partialcorr = rho;
	R.pval		  = pval;


	% ampl_S 		= quantile(max(V, [], 2) - min(V, [], 2), ci);
	% meanVm_S 	= quantile(mean(V, 2), ci);
	% caL_S 		= quantile(CAL, ci);


	% FO_sync_S  = K.stats.firstordersync;
	% SO_sync_S  = K.stats.secondordersync;
	% All_sync_S  = K.stats.overallsync;

	% try
	% 	freq_S = quantile(K.frequency, ci);
	% catch
	% 	freq_S = -1;
	% end

	% pop_r_S  = spikes.popfrequency;
	% prop_f_S = spikes.propspkneurons;

	% W = transients{s}.networkParameters.connectivityMatrix;
	% 	W(W==0) = [];
	% 	truegaps_S = quantile(W, ci) ;

	% W = transients{s}.networkParameters.connectivityMatrix;
	% 	truenconn_S = quantile(sum(W>0), ci) ;

	% end

	% R.summary = table(truegaps_S, truenconn_S, pop_r_S, prop_f_S,  ampl_S, meanVm_S, caL, freq,  FO_sync, SO_sync, All_sync);




if plotme
	try
		CB = flipud(cbrewer('div', 'RdBu',20));
		set(0, 'defaultfigurecolormap', CB)
	catch
		warning('no color brewer')
	end

	figure 
	subplot(121)
	imagesc(rho,[-1 1]); colorbar
	set(gca,'xtick', [1 2 3 4 5 6 7 8], 'xticklabel', R.allneurons.Properties.VariableNames)
	set(gca,'ytick', [1 2 3 4 5 6 7 8], 'yticklabel', R.allneurons.Properties.VariableNames)
	title('partial correlation')

	subplot(122)
	imagesc(pval<0.05); colorbar

	set(gca,'xtick', [1 2 3 4 5 6 7 8], 'xticklabel', R.allneurons.Properties.VariableNames)
	set(gca,'ytick', [1 2 3 4 5 6 7 8], 'yticklabel', R.allneurons.Properties.VariableNames)
	title('p values')

	maximize_fig


	if isfield(sim,'Plist')
		figure
			ca = axis;
			set(0,'defaultaxescolororder', linspecer(length(sim.Plist)))
			% p = plot(tslice,   sim.networkHistory.V_soma');
			p = plot(  sim.networkHistory.V_soma');
			legend(num2str(sim.Plist))

		maximize_fig

		figure
			imagesc(sim.networkHistory.V_soma,[-80 -20]), colorbar
			set(gca,'ytick', [1:length(sim.Plist)],'yticklabel', num2str(sim.Plist),'fontsize',8)
			legend(num2str(sim.Plist))

		maximize_fig

	end

end






% from mathworks

% X = [ones(size(x1)) x1 x2 x1.*x2];
% b = regress(y,X)    % Removes NaN data

% scatter3(x1,x2,y,'filled')
% hold on
% x1fit = min(x1):100:max(x1);
% x2fit = min(x2):10:max(x2);
% [X1FIT,X2FIT] = meshgrid(x1fit,x2fit);
% YFIT = b(1) + b(2)*X1FIT + b(3)*X2FIT + b(4)*X1FIT.*X2FIT;
% mesh(X1FIT,X2FIT,YFIT)



% scatter3(x1,x2,y,'filled')
% hold on
% x1fit = min(x1):100:max(x1);
% x2fit = min(x2):10:max(x2);
% [X1FIT,X2FIT] = meshgrid(x1fit,x2fit);
% YFIT = b(1) + b(2)*X1FIT + b(3)*X2FIT + b(4)*X1FIT.*X2FIT;
% mesh(X1FIT,X2FIT,YFIT)