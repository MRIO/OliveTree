
% openfig_savepng.m

function saveallfigs(varargin)


	p = inputParser;
	
	p.addParamValue('prefix', []) 
	p.addParamValue('path', []) 
	p.addParamValue('formats', []) 
	
	p.parse(varargin{:});
	prefix = p.Results.prefix;
	path = p.Results.path;
	formats = p.Results.formats;



h = get(0,'children');

for i=1:length(h)
	h(i).Color = [1 1 1];
   saveas(h(i), [prefix num2str(i)], 'fig');
   export_fig([prefix num2str(i)], '-png','-m2',h(i))
   % plot2svg([num2str(i) '.svg'],h(i));
end

