F = 'periodic_ampa_moreoscillations_nocorr_2_iso_0.04_spont_50000_2_28-Jun-2016.mat';
F2 = 'periodic_ampa_moreoscillations_nocorr_2_iso_0.04_1Hz_50000_2_28-Jun-2016.mat';
F3 = 'periodic_ampa_moreoscillations_nocorr_2_iso_0.04_gallop_50000_2_28-Jun-2016.mat';

% F = 'periodic_ampa_2_iso_0.04_1Hz_50000_2_12-Jun-2016.mat';
% F2 = 'periodic_ampa_2_iso_0.04_spont_50000_2_12-Jun-2016.mat';

addpath('/Users/M/Synced/Titan/Bench2/periodic_ampa/')
addpath('/Users/M/Synced/Titan/Bench2/')
addpath('/Users/M/Synced/Titan/Bench/')


trigger = 1;


load (F)
numruns = 2;
Joinedsim{1}  = joinsim(simresults,[1:numruns]); 

load (F2)
numruns = 2;
Joinedsim{2}  = joinsim(simresults,[1:numruns]); 

load (F3)
numruns = 2;
Joinedsim{3}  = joinsim(simresults,[1:numruns]); 

M = Joinedsim{2}.perturbation.mask{1};
T = Joinedsim{3}.perturbation.triggers{1};

subplot(121)
scatter(Joinedsim{1}.spikes.spikespercell/100, Joinedsim{2}.spikes.spikespercell/100,100, M,'filled')
axis equal
xlabel('spont freq')
ylabel('1Hz freq')

subplot(122)
scatter(Joinedsim{1}.spikes.spikespercell/100, Joinedsim{3}.spikes.spikespercell/100,100, M+2,'filled')
axis equal
xlabel('spont freq')
ylabel('gallop freq (3Hz)')



D1 = Joinedsim{3}.spikes.spikespercell(M)./ Joinedsim{1}.spikes.spikespercell(M)

D2 = Joinedsim{2}.spikes.spikespercell(M)./ Joinedsim{1}.spikes.spikespercell(M)

boxplot([D1 D2])