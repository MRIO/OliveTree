% phase_response_curves.m

% addpath('4pA')
% a = dir('4pA/*.mat')

addpath(genpath('8pA'))
a = dir('8pA/-8000/*.mat')


clear
addpath(genpath('6pA'))
a = dir('6pA/*.mat')

clear st
clear pd
a = dir('*.mat')
for f = 1:length(a)
	f
	load(a(f).name)
	pd{f} = phase_distribution_over_time(sim3D,[],0);
	stimtime = regexp(a(f).name,'(\d+)ms','tokens');
	st(f) = str2num(stimtime{1}{1});
	text(0.8,0.8,num2str(st(f)))
	clf
	pr1(f,:) = pd{f}.phases.mean(1,:);
	pr2(f,:) = pd{f}.phases.mean(2,:);

end


% PRC for inhibition
% [100:5:250]

% find the peak of the next period
[m1 x1] = max(pr1(:,110:230),[],2); % perturbed
[m2 x2] = max(pr2(:,110:230),[],2); % unperturbed
x1 = x1+110;
x2 = x2+110;

% find the natural period 
[mn1 t1] = min(pr2(:,51:150 ),[],2);
[mn2 t2 ]= min(pr2(:,201:300),[],2);
T =  (t2+200) - (t1+50);

meanT = mean(T);

% plot the PRC
% (x1(1:25)-mean(x2(1:25)))/meanT
% plot(linspace(0,2*pi,25), (x1(1:25)-mean(x2(1:25)))/meanT,'o-')



% PRC for excitation
% [100:5:250]

% find the peak of the next period
[m1 x1] = max(pr1(:,110:250),[],2);
[m2 x2] = max(pr2(:,110:250),[],2);
x1 = x1+110;
x2 = x2+110;

% find the natural period 
[mn1 t1] = min(pr2(:,51:150),[],2);
[mn2 t2 ]= min(pr2(:,201:300),[],2);
T =  (t2+200) - (t1+50);

meanT = mean(T);

inhibitoryPRC = x1(1:25)-mean(x2(1:25)))/meanT;
excitatoryPRC = x1(32:56)-mean(x2(32:56)))/meanT;


%    _   __          __      __     __  __            ____  ____  ______
%   (_)_/_/   ____  / /___  / /_   / /_/ /_  ___     / __ \/ __ \/ ____/
%    _/_/    / __ \/ / __ \/ __/  / __/ __ \/ _ \   / /_/ / /_/ / /     
%  _/_/_    / /_/ / / /_/ / /_   / /_/ / / /  __/  / ____/ _, _/ /___   
% /_/ (_)  / .___/_/\____/\__/   \__/_/ /_/\___/  /_/   /_/ |_|\____/   
%         /_/                                                           
figure
xphase = linspace(-pi,pi,25);
hold on
plot(xphase, (inhibitoryPRC,'o-b','linewidth',2)
plot(xphase, (inhibitoryPRC,'ow','linewidth',1)
plot(xphase , (excitatoryPRC,'o-r','linewidth',2)
plot(xphase , (excitatoryPRC,'ow','linewidth',1)

xlabel('phase of perturbation (radians)')
ylabel('phase delta (% of T)')

title('phase response curve for stimuli')
grid on
xlim([-pi pi])
export_fig('prc_both','-m4')





