


()-- do correlations based on calcium expression!

measureGlobalSync(results)

spikedetect(results)

replayResults(results)

replayResults_clusters(results)

stim_trig_spks(results)

