function out = if_network(varargin) % we are going to parse the parameters
% this function simulates a network of conductance based integrate and fire neurons.
% it takes the following keyworkd-value parameters (parameter name, def):
% 
% 'sim_time', 1               	    % 1sec                             
% 'dt', 0.001                 	  % timestep                     
% 'v_init', -.70              	 % resting membrane potential   
% 'v_thresh', -.50            	    % threshold membrane potential 
% 'mem_tc', 0.02              	   % membrane time constant       
% 'syn_tc', 0.005             	    % synaptic time constant       
% 'v_syn', 0                  	  % reversal synaptic potential   
% 'w', .5                     	 % weight matrix scaling function
% 'epsc_amplitude', 2         	    % epsc amplitude               
% 'poisson_firing_rate', 10   	   % poisson firing rate     
% 'plot_flag', true           	   % plot results?                 
                                                     
%%=================================================================     Function


%%% Cool concept: Input Parser %%%
% The input parser takes these keyword-value pairs
% if ommitted, they take the standard values
% one can pass the simulation parameters to it.

p = inputParser;

p.addRequired('stimulus') 
p.addRequired('connectionmatrix')
p.addParamValue('dt', .1) 	      % dt in ms
p.addParamValue('v_init', -70)       % resting membrane potential (mV)
p.addParamValue('v_reset', -70)
p.addParamValue('v_thresh', -40.4)    % threshold membrane potential
p.addParamValue('mem_tc', 20 )    % membrane time constant (ms)
p.addParamValue('syn_tc', 5 )    % synaptic time constant (ms)
p.addParamValue('v_syn', 0 )       % reversal synaptic potential
p.addParamValue('epsc_amplitude', 5 )% epsc amplitude
p.addParamValue('plot_flag', true)   % plot results?
p.addParamValue('a', 4)   % nS refractory variable slope
p.addParamValue('b', 805)   % nA adaptation increment
p.addParamValue('tau_w', 144)   % adaptation time constant (ms)
p.addParamValue('C', 281) % pF
p.addParamValue('gL', 30) % nS
p.addParamValue('EL', -70.6) %mV
p.addParamValue('DeltaT',2)

v_spk  = -20;

p.parse(varargin{:});
% pass the results of parsing to the local variables

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Simulation parameters %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                               
stim       		     = p.Results.stimulus        ;
W 				         = p.Results.connectionmatrix;
dt                 = p.Results.dt              ;
v_init             = p.Results.v_init          ;
v_reset            = p.Results.v_reset         ;
v_thres            = p.Results.v_thresh        ;
mem_tc             = p.Results.mem_tc          ;
syn_tc             = p.Results.syn_tc          ;
v_syn              = p.Results.v_syn           ;
epsc_amplitude     = p.Results.epsc_amplitude  ;
plotFlag           = p.Results.plot_flag       ;
tau_w              = p.Results.tau_w;
a                  = p.Results.a       ;
b                  = p.Results.b       ;
C                  = p.Results.C       ;
gL                 = p.Results.gL       ;
EL                 = p.Results.EL       ;
DeltaT             = p.Results.DeltaT       ;


[no_input_neurons sim_time] = size(stim);
no_neurons = length(W);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Overall Parameters    %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

plotFlag = false;

%%%%%%%%%%%%%%%%%%%%%%
%%% initialisation %%%
%%%%%%%%%%%%%%%%%%%%%%

if length(v_init) > 1
	V = v_init;
else	
	V = [ v_init*ones(no_neurons,1) ];
end

g_in = zeros(no_neurons,1);
w = zeros(no_neurons,1);

sim_steps = sim_time;

V_log = zeros(no_neurons, sim_steps);
spk_log = zeros(no_neurons, sim_steps);

spks = zeros(no_neurons,1);

%%%%%%%%%%%%%%%%%%%%%%%
%%% Simulation loop %%%
%%%%%%%%%%%%%%%%%%%%%%%


for step=1:sim_steps
	
       %%% update conductances based on input and spiking %%%

     
       g_in_new = W*spks*epsc_amplitude ; % update synaptic conductances (weight matrix times activity vector)

       % reset spike register
       spks = zeros(no_neurons,1);

       g_in = g_in + g_in_new;

       I_curr = stim(:,step);
   
       I_in = -g_in.*(V - v_syn); % current is conductance times voltage (I=RV)
   
       

       %%% update membrane potentials with input currents %%%

       % (gL*(EL-vm)+gL*DeltaT*exp((vm-VT)/DeltaT)+I-w)/C

       dV_dt = ( gL.*(EL-V) + gL.*DeltaT*exp((V-v_thres)/DeltaT)  + I_in + I_curr - w )./C ;

       V = V + dV_dt*dt;

       % dw/dt=(a*(vm-EL)-w)/tauw
       dw_dt =  (a*(V-EL) -w )./tau_w;

       w = w + dw_dt*dt;

   
       %%% decay conductances %%%   
       g_in = g_in - (g_in ./ syn_tc )*dt;

       %%% find index of spiking cells %%%
      spk_neurons = find(V >= v_spk);

      %%% reset neurons that crossed threshold %%%
      V(spk_neurons) = v_reset;

      w(spk_neurons) = w(spk_neurons) + b;
      
      % keep track
      I_in_log(step,:) = I_in + I_curr; 
      V_log(:, step) = V;
      spk_log(spk_neurons,step) = 1;
      spks = spk_log(:, step);
      g_in_log(:, step) = g_in;
      w_log(:,step) = w;


end

%%%%%%%%%%%%%%%%%%%
%%% statistics  %%%
%%%%%%%%%%%%%%%%%%%

fr = @(r) mean(1./diff(find(spk_log(r,:))));
rate = arrayfun(fr, [1:no_neurons]);


%%%%%%%%%%%%%%%%%%%
%%% plot output %%%
%%%%%%%%%%%%%%%%%%%

if plotFlag

   %%% plot the evolution of the membrane potentials
   pcolor(V_log)
   shading flat
   colormap copper
   colorbar
   
   %%% raster plot %%%
   % find the spiking times of all neurons
   [spiking_neurons spiking_times] = find(spk_log);

   % define a function that produces a dot for the I J pairs (does not require hold on!)
   l = @(i,j)(line(i,j,'marker','.', 'linestyle', 'none', 'color', [1 1 0]));
   
   hold on
   % apply the function
   arrayfun(l, spiking_times, spiking_neurons )

   %%% prepare the legends
   title('Membrane potential and spikes')
   xlabel('ms')
   ylabel('neuron')
   
end



%%===================================================================     OUTPUT
out.V_log = V_log;
out.spk_log = spk_log;
out.rate = rate;
out.I_in_log = I_in_log;
out.g_in_log = g_in_log;
out.w_log     = w_log;




