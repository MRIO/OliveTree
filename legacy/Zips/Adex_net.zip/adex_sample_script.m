% adex_sample_script.m


% notes:
% - simulation time is defined by duration of stimulus array with resolution dt
%   simtime = size(stim,2)*dt; (seconds)

nneurons = 50;
simtime = 1000; %ms
dt = .1;

% generate stimulus
stim = rand(nneurons,simtime*(1/dt));
stim(1,1500:2550) = 1000; %pA

% generate connectivity
connectionmatrix = subplus(randn(nneurons))*5;
connectionmatrix(find(eye(nneurons))) = 0;

%run network
results = Adex_network(stim, connectionmatrix)


% parameters for the network

% p.addRequired('stimulus') 
% p.addRequired('connectionmatrix')
% p.addParamValue('dt', .1) 	      % dt in ms
% p.addParamValue('v_init', -70)       % resting membrane potential (mV)
% p.addParamValue('v_reset', -70)
% p.addParamValue('v_thresh', -40.4)    % threshold membrane potential
% p.addParamValue('mem_tc', 20 )    % membrane time constant (ms)
% p.addParamValue('syn_tc', 5 )    % synaptic time constant (ms)
% p.addParamValue('v_syn', 0 )       % reversal synaptic potential
% p.addParamValue('epsc_amplitude', 5 )% epsc amplitude
% p.addParamValue('plot_flag', true)   % plot results?
% p.addParamValue('a', 4)   % nS refractory variable slope
% p.addParamValue('b', 805)   % nA adaptation increment
% p.addParamValue('tau_w', 144)   % adaptation time constant (ms)
% p.addParamValue('C', 281) % pF
% p.addParamValue('gL', 30) % nS
% p.addParamValue('EL', -70.6) %mV
% p.addParamValue('DeltaT',2)